export default function SavedPrograms() {
    return (
        <div className="bg-white shadow rounded-xl p-6 border border-gray-100 text-gray-600">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Saved Programs</h2>
            <p>You haven’t saved any programs yet.</p>
        </div>
    );
}
